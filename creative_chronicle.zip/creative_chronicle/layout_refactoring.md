# BÁO CÁO TÁI CẤU TRÚC GIAO DIỆN CƠ BẢN (LAYOUT REFACTORING REPORT)

**Tác giả:** Frontend UI Developer  
**Dự án:** CreativeChronicle Magazine Refactoring  

## Phân tích tác hại của `position: absolute` đối với Responsive Design

Thuộc tính `position: absolute` rút hoàn toàn phần tử ra khỏi luồng render tự nhiên của DOM (Normal Document Flow). Khung cha chứa nó không thể tự động tính toán chiều cao thực tế, buộc lập trình viên phải gán chiều cao cứng (ví dụ: `height: 400px`).

Khi xem trên thiết bị di động (màn hình hẹp), nội dung con không thể tự động hạ xuống dòng hoặc thay đổi tỷ lệ tương thích. Hậu quả là các hình ảnh/thẻ con chồng chéo lên nhau và đè bẹp lên nội dung bài viết tiếp theo.

## CSS Grid - Giải pháp Cứu cánh cho Bố cục 2 Chiều (2D Layout)

CSS Grid giải quyết triệt để bài toán dàn trang bằng cách thiết lập một hệ thống lưới 2 chiều (hàng và cột đồng thời):
1. **Duy trì DOM Flow:** Khung cha tự động mở rộng ôm trọn các hình ảnh mà không cần hack `height`.
2. **Linh hoạt Media Queries:** Dễ dàng chuyển đổi từ 2 cột (`2fr 1fr`) trên Desktop về 1 cột dọc (`1fr`) trên Mobile chỉ với vài dòng CSS.
3. **Tránh biến dạng ảnh:** Kết hợp với `object-fit: cover` giúp hình ảnh giữ nguyên tỷ lệ thẩm mỹ chuẩn tòa soạn báo mà không bị co bóp méo hình.