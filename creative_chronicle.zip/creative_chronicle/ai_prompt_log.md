# NHẬT KÝ TƯƠNG TÁC VỚI AI (AI PROMPT LOG)

## Prompt 1: Tra cứu thuộc tính CSS Grid cho Mosaic Gallery
* **User Query:** "Làm thế nào để tạo một bố cục ảnh dạng Mosaic gồm 1 ảnh lớn bên trái chiếm 2 hàng và 2 ảnh nhỏ bên phải xếp chồng lên nhau bằng CSS Grid?"
* **AI Output:** Định nghĩa `grid-template-columns: 2fr 1fr;` và `grid-template-rows: repeat(2, 200px);`. Ảnh chính sử dụng `grid-row: span 2;` kết hợp `object-fit: cover` để tự kéo giãn full 2 hàng mà không bị méo tỷ lệ.

## Prompt 2: Tìm hiểu Bootstrap 5 Utilities cho Author Info
* **User Query:** "Có những class Utilities nào của Bootstrap 5 giúp căn giữa các phần tử theo chiều dọc và giãn đều 2 đầu mà không cần viết CSS thuần?"
* **AI Output:** Sử dụng `d-flex` (định nghĩa flex container), `align-items-center` (căn giữa trục dọc), `justify-content-space-between` (giãn đều 2 đầu) và `gap-2` (khoảng cách giữa các phần tử con).

## Prompt 3: Tìm hiểu Responsive Breakpoints của Bootstrap Grid
* **User Query:** "Cú pháp lớp chia cột trong Bootstrap 5 để 1 hàng có 4 cột trên Desktop (>=992px), 2 cột trên Tablet (>=768px) và 1 cột trên Mobile (<768px) là gì?"
* **AI Output:** Sử dụng kết hợp class: `col-12 col-md-6 col-lg-3`.