# ProductManagement — Java Servlet, JSP, JDBC, MySQL

## Yêu cầu
- JDK 17
- Apache Tomcat 10.1.x
- Maven 3.8+
- MySQL 8.x

Tomcat 10.1 dùng `jakarta.servlet`; không đổi import sang `javax.servlet`.

## 1. Tạo cơ sở dữ liệu
Mở MySQL Workbench, chạy `database.sql`. Nếu chạy file nhiều lần, các dòng dữ liệu mẫu có thể được thêm lặp lại.

## 2. Cấu hình tài khoản MySQL
Mở `src/main/java/com/example/product/util/DBConnection.java` và sửa `USER`, `PASSWORD` cho đúng tài khoản MySQL trên máy bạn. Không dùng chuỗi `PASSWORD` mặc định; hãy thay bằng mật khẩu thật hoặc `""` nếu tài khoản root không có mật khẩu.

## 3. Kiểm tra công cụ trong terminal VS Code
```powershell
java -version
mvn -version
```
Nếu `mvn` không được nhận diện, cài Maven và thêm thư mục `bin` vào PATH. Mở terminal mới sau khi sửa PATH.

## 4. Build WAR
Trong terminal, tại thư mục chứa `pom.xml`:
```powershell
mvn clean package
```
File đầu ra: `target/ProductManagement.war`.

## 5. Chạy trên Tomcat 10.1
- Dừng Tomcat nếu đang chạy.
- Sao chép `target/ProductManagement.war` vào thư mục `webapps` của Tomcat 10.1.
- Khởi động Tomcat bằng `bin\startup.bat` (Windows).
- Mở `http://localhost:8080/ProductManagement/products`.

Nếu Tomcat đang chạy dưới dạng Windows Service, có thể khởi động/dừng bằng Services thay vì startup/shutdown scripts.

## Chức năng
- Xem danh sách sản phẩm
- Thêm sản phẩm, kiểm tra tên/giá/số lượng
- Sửa sản phẩm theo ID
- Xóa sản phẩm có xác nhận, gửi POST
- JDBC dùng PreparedStatement

## Cấu trúc
- `model/Product.java`: dữ liệu sản phẩm
- `dao/ProductDAO.java`: truy vấn SQL
- `util/DBConnection.java`: kết nối MySQL
- `servlet/ProductServlet.java`: xử lý yêu cầu HTTP
- `WEB-INF/views/*.jsp`: giao diện JSP
- `database.sql`: tạo bảng và dữ liệu mẫu

## Đóng gói bài nộp
Nộp thư mục dự án gồm `src`, `pom.xml`, `database.sql`, `README.md`; có thể giữ `target` hoặc không. Đổi tên file zip theo mã sinh viên, ví dụ `123456_FinalExam.zip`.
