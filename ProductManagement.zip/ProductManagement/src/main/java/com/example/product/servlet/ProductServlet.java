package com.example.product.servlet;

import com.example.product.dao.ProductDAO;
import com.example.product.model.Product;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.SQLException;

@WebServlet(urlPatterns = {"/products", "/products/add", "/products/edit", "/products/delete"})
public class ProductServlet extends HttpServlet {
    private final ProductDAO dao = new ProductDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String path = request.getServletPath();
        try {
            if ("/products/edit".equals(path)) {
                int id = parsePositiveInt(request.getParameter("id"));
                Product product = dao.findById(id);
                if (product == null) { response.sendError(HttpServletResponse.SC_NOT_FOUND, "Không tìm thấy sản phẩm."); return; }
                request.setAttribute("product", product);
                request.getRequestDispatcher("/WEB-INF/views/edit.jsp").forward(request, response);
                return;
            }
            request.setAttribute("products", dao.findAll());
            request.getRequestDispatcher("/WEB-INF/views/index.jsp").forward(request, response);
        } catch (IllegalArgumentException e) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "ID không hợp lệ.");
        } catch (SQLException e) { throw new ServletException("Không thể truy cập cơ sở dữ liệu.", e); }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String path = request.getServletPath();
        try {
            if ("/products/add".equals(path)) {
                Product p = readProduct(request);
                dao.insert(p);
                response.sendRedirect(request.getContextPath() + "/products?success=added");
            } else if ("/products/edit".equals(path)) {
                int id = parsePositiveInt(request.getParameter("id"));
                Product p = readProduct(request); p.setId(id);
                if (!dao.update(p)) { response.sendError(HttpServletResponse.SC_NOT_FOUND, "Không tìm thấy sản phẩm để sửa."); return; }
                response.sendRedirect(request.getContextPath() + "/products?success=updated");
            } else if ("/products/delete".equals(path)) {
                int id = parsePositiveInt(request.getParameter("id"));
                if (!dao.delete(id)) { response.sendError(HttpServletResponse.SC_NOT_FOUND, "Không tìm thấy sản phẩm để xóa."); return; }
                response.sendRedirect(request.getContextPath() + "/products?success=deleted");
            } else response.sendError(HttpServletResponse.SC_NOT_FOUND);
        } catch (IllegalArgumentException e) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, e.getMessage());
        } catch (SQLException e) { throw new ServletException("Không thể lưu dữ liệu vào cơ sở dữ liệu.", e); }
    }

    private Product readProduct(HttpServletRequest request) {
        String name = request.getParameter("name");
        String priceText = request.getParameter("price");
        String quantityText = request.getParameter("quantity");
        if (name == null || name.trim().isEmpty()) throw new IllegalArgumentException("Tên sản phẩm không được để trống.");
        try {
            BigDecimal price = new BigDecimal(priceText);
            int quantity = Integer.parseInt(quantityText);
            if (price.compareTo(BigDecimal.ZERO) < 0) throw new IllegalArgumentException("Giá không được âm.");
            if (quantity < 0) throw new IllegalArgumentException("Số lượng không được âm.");
            return new Product(0, name.trim(), price, quantity);
        } catch (NumberFormatException | NullPointerException e) {
            throw new IllegalArgumentException("Giá hoặc số lượng không hợp lệ.");
        }
    }

    private int parsePositiveInt(String value) {
        try { int id = Integer.parseInt(value); if (id > 0) return id; }
        catch (NumberFormatException | NullPointerException ignored) {}
        throw new IllegalArgumentException("ID không hợp lệ.");
    }
}
