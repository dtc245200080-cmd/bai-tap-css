<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html><html lang="vi"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Quản lý sản phẩm</title><link rel="stylesheet" href="${pageContext.request.contextPath}/assets/style.css"></head>
<body><main class="container"><header><div><p class="eyebrow">PRODUCT MANAGEMENT</p><h1>Quản lý sản phẩm</h1><p class="muted">Thêm, cập nhật và quản lý kho sản phẩm.</p></div></header>
<c:if test="${param.success == 'added'}"><div class="alert success">Thêm sản phẩm thành công.</div></c:if><c:if test="${param.success == 'updated'}"><div class="alert success">Cập nhật sản phẩm thành công.</div></c:if><c:if test="${param.success == 'deleted'}"><div class="alert success">Xóa sản phẩm thành công.</div></c:if>
<section class="panel"><h2>Thêm sản phẩm mới</h2><form action="${pageContext.request.contextPath}/products/add" method="post" class="product-form">
<label>Tên sản phẩm<input type="text" name="name" maxlength="255" required placeholder="Ví dụ: Bàn phím cơ"></label>
<label>Giá (VNĐ)<input type="number" name="price" min="0" step="0.01" required placeholder="850000"></label>
<label>Số lượng<input type="number" name="quantity" min="0" step="1" required placeholder="10"></label><button type="submit" class="btn primary">+ Thêm sản phẩm</button></form></section>
<section class="panel"><div class="section-heading"><div><h2>Danh sách sản phẩm</h2><p class="muted">Tổng số: <strong><c:out value="${products.size()}"/></strong> sản phẩm</p></div></div>
<div class="table-wrap"><table><thead><tr><th>ID</th><th>Tên sản phẩm</th><th>Giá (VNĐ)</th><th>Số lượng</th><th>Thao tác</th></tr></thead><tbody>
<c:forEach var="p" items="${products}"><tr><td>#<c:out value="${p.id}"/></td><td class="product-name"><c:out value="${p.name}"/></td><td><c:out value="${p.price}"/></td><td><span class="quantity"><c:out value="${p.quantity}"/></span></td><td><div class="actions"><a class="btn small" href="${pageContext.request.contextPath}/products/edit?id=${p.id}">Sửa</a><form action="${pageContext.request.contextPath}/products/delete" method="post" onsubmit="return confirm('Bạn có chắc chắn muốn xóa sản phẩm này?');"><input type="hidden" name="id" value="${p.id}"><button type="submit" class="btn small danger">Xóa</button></form></div></td></tr></c:forEach>
<c:if test="${empty products}"><tr><td colspan="5" class="empty">Chưa có sản phẩm. Hãy thêm sản phẩm đầu tiên.</td></tr></c:if>
</tbody></table></div></section><footer>Java Servlet · JSP · JDBC · MySQL</footer></main></body></html>
