CREATE DATABASE IF NOT EXISTS product_management
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE product_management;

CREATE TABLE IF NOT EXISTS products (
  id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(255) NOT NULL,
  price DECIMAL(12,2) NOT NULL,
  quantity INT NOT NULL
);

INSERT INTO products (name, price, quantity) VALUES
('Laptop Acer', 12000000.00, 10),
('Chuột máy tính', 250000.00, 30),
('Bàn phím cơ', 850000.00, 15);
