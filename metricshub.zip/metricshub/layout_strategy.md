# CHIẾN LƯỢC DÀN TRANG: CSS GRID VS FLEXBOX

**Tác giả:** Front-end UI/UX Engineer  
**Dự án:** MetricsHub Dashboard Refactor  

## Triết lý Thiết kế: 2D Framework vs 1D Components

1. **CSS Grid sinh ra cho Layout 2D (Tổng thể):** 
   Nó cho phép định nghĩa các ô lưới theo cả trục ngang (Columns) và trục dọc (Rows) đồng thời từ container cha. Trong bài toán Bento Dashboard, CSS Grid giúp tháo gỡ hoàn toàn các thẻ `.column` trung gian (Shallow DOM), giúp việc điều hướng phần tử dạng `span 2 rows / span 2 cols` diễn ra tự nhiên.

2. **Flexbox sinh ra cho Component 1D (Chi tiết):**
   Flexbox quản lý sự phân bổ không gian theo 1 chiều duy nhất (Content-first). Áp dụng cho Navbar giúp các phần tử (Logo, Links, Profile) tự động giãn khoảng cách linh hoạt dựa theo độ dài nội dung thực tế (kể cả tiếng Đức), không bị đè chữ hay tràn khung như CSS Grid cố định (`px`).

3. **Bootstrap Grid cho Rapid Responsive Components:**
   Dùng hệ thống 12 cột cho khu vực Pricing giúp tiết kiệm thời gian viết Media Queries thuần, đảm bảo giao diện tự động chuyển từ 3 cột (Desktop) về 1 cột xếp chồng (Mobile) tiêu chuẩn.