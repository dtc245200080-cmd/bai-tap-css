# NHẬT KÝ TƯƠNG TÁC AI (AI PROMPT LOG)

## Prompt 1: Khái niệm 1D Flexbox vs 2D Grid
* **User Query:** "Khi nào nên dùng CSS Grid và khi nào nên dùng Flexbox? Cho ví dụ về lỗi Div Soup khi dùng Flexbox làm Bento Box."
* **AI Output:** Flexbox là 1D (dòng HOẶC cột), CSS Grid là 2D (dòng VÀ cột cùng lúc). Để làm Bento Box bằng Flexbox, lập trình viên buộc phải bọc nhiều thẻ `div` phân cột làm DOM bị lồng sâu (Div Soup). Dùng CSS Grid sẽ giúp làm phẳng cấu trúc HTML.

## Prompt 2: Tìm hiểu thuộc tính `gap` trong CSS
* **User Query:** "Thuộc tính `gap` hoạt động thế nào trong cả Flexbox và CSS Grid? Tại sao nó tốt hơn việc dùng `margin` cho các item?"
* **AI Output:** `gap` (trước đây là `grid-gap`) định nghĩa khoảng cách TRỰC TIẾP giữa các item con từ container cha. Khi dùng `margin`, ta phải dùng `:last-child` hoặc `:first-child` để xóa margin thừa ở cạnh biên. `gap` tự động bỏ qua khoảng cách ngoài biên, giúp CSS sạch hơn.

## Prompt 3: Tìm hiểu Bootstrap 5 Breakpoints
* **User Query:** "Phân biệt các lớp col-12, col-md-4 trong Bootstrap 5 và cơ chế mobile-first."
* **AI Output:** Lớp `col-12` áp dụng mặc định từ kích thước màn hình nhỏ nhất (Mobile-first). Lớp `col-md-4` kích hoạt khi viewport $\ge 768px$, giúp phần tử chiếm $4/12$ cột ($33.33\%$). Kết hợp lại giúp Pricing Card hiển thị 1 cột trên Mobile và 3 cột trên Tablet/Desktop.