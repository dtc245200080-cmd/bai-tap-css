
<%@ page contentType="text/html; charset=UTF-8"
         pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Danh sách khách hàng</title>

    <style>
        body {
            font-family: "Times New Roman", serif;
            font-size: 14px;
        }

        .container {
            width: 420px;
            margin: 30px auto;
            padding: 10px;
            border: 3px solid #c5dff2;
            box-shadow: 0 0 6px #8bbce0;
        }

        h2 {
            text-align: center;
            margin: 0 0 10px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 10px 0;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            font-weight: bold;
        }

        td img {
            width: 40px;
            height: 40px;
            object-fit: cover;
        }
    </style>
</head>

<body>

<%
    // Tạo danh sách khách hàng
    java.util.List<java.util.Map<String, String>> customers =
        new java.util.ArrayList<>();

    java.util.Map<String, String> customer1 =
        new java.util.HashMap<>();
    customer1.put("name", "Mai Văn Hoàn");
    customer1.put("birthday", "1983-08-20");
    customer1.put("address", "Hà Nội");
    customer1.put("image", "images/khachhang1.jpg");
    customers.add(customer1);

    java.util.Map<String, String> customer2 =
        new java.util.HashMap<>();
    customer2.put("name", "Nguyễn Văn Nam");
    customer2.put("birthday", "1983-08-21");
    customer2.put("address", "Bắc Giang");
    customer2.put("image", "images/khachhang2.jpg");
    customers.add(customer2);

    java.util.Map<String, String> customer3 =
        new java.util.HashMap<>();
    customer3.put("name", "Nguyễn Thái Hòa");
    customer3.put("birthday", "1983-08-22");
    customer3.put("address", "Nam Định");
    customer3.put("image", "images/khachhang3.jpg");
    customers.add(customer3);

    java.util.Map<String, String> customer4 =
        new java.util.HashMap<>();
    customer4.put("name", "Trần Đăng Khoa");
    customer4.put("birthday", "1983-08-17");
    customer4.put("address", "Hà Tây");
    customer4.put("image", "images/khachhang4.jpg");
    customers.add(customer4);

    java.util.Map<String, String> customer5 =
        new java.util.HashMap<>();
    customer5.put("name", "Nguyễn Đình Thi");
    customer5.put("birthday", "1983-08-19");
    customer5.put("address", "Hà Nội");
    customer5.put("image", "images/khachhang5.jpg");
    customers.add(customer5);

    request.setAttribute("customers", customers);
%>

<div class="container">
    <h2>Danh sách khách hàng</h2>

    <table>
        <thead>
            <tr>
                <th>Tên</th>
                <th>Ngày sinh</th>
                <th>Địa chỉ</th>
                <th>Ảnh</th>
            </tr>
        </thead>

        <tbody>
            <c:forEach var="customer" items="${customers}">
                <tr>
                    <td><c:out value="${customer.name}"/></td>
                    <td><c:out value="${customer.birthday}"/></td>
                    <td><c:out value="${customer.address}"/></td>
                    <td>
                        <img
                            src="<c:out value='${customer.image}'/>"
                            alt="Ảnh khách hàng">
                    </td>
                </tr>
            </c:forEach>
        </tbody>
    </table>
</div>

</body>
</html>
