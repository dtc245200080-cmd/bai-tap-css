package com.codegym;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.math.BigDecimal;

public class ConverterServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");

        try {
            BigDecimal rate = new BigDecimal(request.getParameter("rate"));
            BigDecimal usd = new BigDecimal(request.getParameter("usd"));
            BigDecimal vnd = usd.multiply(rate).stripTrailingZeros();

            response.getWriter().printf(
                    "<!DOCTYPE html>%n<html lang=\"vi\">%n<head>%n"
                            + "    <meta charset=\"UTF-8\">%n"
                            + "    <title>Kết quả chuyển đổi</title>%n"
                            + "</head>%n<body>%n"
                            + "    <h1>Kết quả chuyển đổi</h1>%n"
                            + "    <p>Số tiền VNĐ: %s</p>%n"
                            + "    <a href=\"%s/\">Chuyển đổi lại</a>%n"
                            + "</body>%n</html>%n",
                    vnd.toPlainString(), request.getContextPath());
        } catch (NumberFormatException | NullPointerException exception) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST,
                    "Vui lòng nhập tỉ giá và lượng USD hợp lệ.");
        }
    }
}
