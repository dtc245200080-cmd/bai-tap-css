<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%
    request.setCharacterEncoding("UTF-8");

    float vnd = 0;
    String errorMessage = null;
    try {
        float rate = Float.parseFloat(request.getParameter("rate"));
        float usd = Float.parseFloat(request.getParameter("usd"));
        if (!Float.isFinite(rate) || !Float.isFinite(usd)) {
            throw new NumberFormatException();
        }
        vnd = usd * rate;
    } catch (NumberFormatException | NullPointerException exception) {
        errorMessage = "Vui lòng nhập tỉ giá và lượng USD hợp lệ.";
    }
%>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Kết quả chuyển đổi</title>
</head>
<body>
    <h1>Kết quả chuyển đổi</h1>
    <% if (errorMessage != null) { %>
        <p role="alert"><%= errorMessage %></p>
    <% } else { %>
        <p>Số tiền VNĐ: <%= vnd %></p>
    <% } %>
    <a href="index.jsp">Chuyển đổi lại</a>
</body>
</html>
