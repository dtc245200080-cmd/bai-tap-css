<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Chuyển đổi tiền tệ</title>
</head>
<body>
    <h1>Chuyển đổi USD sang VNĐ</h1>
    <form action="${pageContext.request.contextPath}/convert" method="post">
        <div>
            <label for="rate">Tỉ giá:</label>
            <input type="number" id="rate" name="rate" min="0" step="any" required>
        </div>
        <div>
            <label for="usd">Lượng USD:</label>
            <input type="number" id="usd" name="usd" min="0" step="any" required>
        </div>
        <button type="submit">Chuyển đổi</button>
    </form>
</body>
</html>
