package com.codegym.service;

import com.codegym.model.Customer;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Khung triển khai dịch vụ khách hàng với kho dữ liệu Map tĩnh.
 */
public class CustomerServiceImpl implements CustomerService {
    private static final Map<Integer, Customer> CUSTOMERS = new HashMap<>();

    /** {@inheritDoc} */
    @Override
    public List<Customer> findAll() {
        return null;
    }

    /** {@inheritDoc} */
    @Override
    public Customer findById(int id) {
        return null;
    }

    /** {@inheritDoc} */
    @Override
    public void save(Customer customer) {
    }

    /** {@inheritDoc} */
    @Override
    public void update(int id, Customer customer) {
    }

    /** {@inheritDoc} */
    @Override
    public void delete(int id) {
    }
}
