package com.codegym.model;

/**
 * Mô hình dữ liệu khách hàng gồm mã, tên, email và địa chỉ.
 */
public class Customer {
    private int id;
    private String name;
    private String email;
    private String address;
}
