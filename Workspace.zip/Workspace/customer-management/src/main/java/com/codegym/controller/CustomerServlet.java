package com.codegym.controller;

import jakarta.servlet.http.HttpServlet;

/**
 * Servlet khung điều phối các yêu cầu quản lý khách hàng tại /customers.
 */
public class CustomerServlet extends HttpServlet {
}
