<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html>
<head>
    <title>User List</title>
</head>
<body>
<h1>User Management</h1>
<p>
    <a href="${pageContext.request.contextPath}/users?action=create">Add New User</a>
</p>

<form method="get" action="${pageContext.request.contextPath}/users">
    <input type="hidden" name="action" value="search">
    <label>
        Country:
        <input type="text" name="country" value="${searchCountry}">
    </label>
    <button type="submit">Search</button>
    <a href="${pageContext.request.contextPath}/users">Reset</a>
    <a href="${pageContext.request.contextPath}/users?action=sort">Sort by name</a>
</form>

<table border="1" cellpadding="5">
    <caption><h2>List of Users</h2></caption>
    <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Email</th>
        <th>Country</th>
        <th>Actions</th>
    </tr>
    <c:forEach var="user" items="${listUser}">
        <tr>
            <td><c:out value="${user.id}"/></td>
            <td><c:out value="${user.name}"/></td>
            <td><c:out value="${user.email}"/></td>
            <td><c:out value="${user.country}"/></td>
            <td>
                <a href="${pageContext.request.contextPath}/users?action=edit&id=${user.id}">Edit</a>
                &nbsp;
                <a href="${pageContext.request.contextPath}/users?action=delete&id=${user.id}">Delete</a>
            </td>
        </tr>
    </c:forEach>
</table>
</body>
</html>
