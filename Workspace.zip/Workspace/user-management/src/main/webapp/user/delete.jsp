<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html>
<head>
    <title>Delete User</title>
</head>
<body>
<h1>User Management</h1>
<h2>Confirm Delete</h2>
<p>Are you sure you want to delete this user?</p>
<table border="1" cellpadding="5">
    <tr>
        <th>ID</th>
        <td><c:out value="${user.id}"/></td>
    </tr>
    <tr>
        <th>Name</th>
        <td><c:out value="${user.name}"/></td>
    </tr>
    <tr>
        <th>Email</th>
        <td><c:out value="${user.email}"/></td>
    </tr>
    <tr>
        <th>Country</th>
        <td><c:out value="${user.country}"/></td>
    </tr>
</table>
<form method="post" action="${pageContext.request.contextPath}/users">
    <input type="hidden" name="action" value="remove">
    <input type="hidden" name="id" value="${user.id}">
    <button type="submit">Delete</button>
    <a href="${pageContext.request.contextPath}/users">Cancel</a>
</form>
</body>
</html>
