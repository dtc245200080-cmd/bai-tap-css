<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html>
<head>
    <title>Edit User</title>
</head>
<body>
<h1>User Management</h1>
<h2>Edit User</h2>
<form method="post" action="${pageContext.request.contextPath}/users">
    <input type="hidden" name="action" value="update">
    <input type="hidden" name="id" value="${user.id}">
    <table>
        <tr>
            <th>User Name:</th>
            <td><input type="text" name="name" value="<c:out value='${user.name}'/>" required></td>
        </tr>
        <tr>
            <th>User Email:</th>
            <td><input type="email" name="email" value="<c:out value='${user.email}'/>" required></td>
        </tr>
        <tr>
            <th>Country:</th>
            <td><input type="text" name="country" value="<c:out value='${user.country}'/>"></td>
        </tr>
        <tr>
            <td colspan="2" align="center">
                <input type="submit" value="Save">
            </td>
        </tr>
    </table>
</form>
<p><a href="${pageContext.request.contextPath}/users">Back to list</a></p>
</body>
</html>
