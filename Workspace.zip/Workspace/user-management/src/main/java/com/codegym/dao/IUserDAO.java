package com.codegym.dao;

import com.codegym.model.User;

import java.sql.SQLException;
import java.util.List;

public interface IUserDAO {
    void insertUser(User user) throws SQLException;

    User selectUser(int id);

    List<User> selectAllUsers();

    boolean deleteUser(int id) throws SQLException;

    boolean updateUser(User user) throws SQLException;

    /**
     * Tìm kiếm user theo quốc gia (so khớp gần đúng, không phân biệt hoa thường).
     */
    List<User> findByCountry(String country);

    /**
     * Lấy danh sách user sắp xếp tăng dần theo name.
     */
    List<User> sortByName();
}
