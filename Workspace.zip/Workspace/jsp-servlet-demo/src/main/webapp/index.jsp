
<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%
    java.time.LocalDateTime now = java.time.LocalDateTime.now();
    java.time.format.DateTimeFormatter formatter =
        java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
%>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Java Web Demo</title>
</head>
<body style="font-family:Arial;text-align:center;margin-top:100px;background:#f8fafc">
    <h1>Chào mừng tới lớp học Java Web!</h1>
    <p>Đây là trang JSP chạy trên Apache Tomcat.</p>

    <p>Thời gian hiện tại của máy chủ:</p>
    <h2><%= now.format(formatter) %></h2>

    <a href="hello">Đi tới HelloServlet</a>
</body>
</html>
