package com.codegym.dictionary;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Map;

public class DictionaryServlet extends HttpServlet {
    private static final Map<String, String> DICTIONARY = Map.of(
            "hello", "Xin chào",
            "book", "Quyển sách",
            "computer", "Máy tính"
    );

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");

        String word = request.getParameter("word");
        String searchWord = word == null ? "" : word.trim();
        String meaning = DICTIONARY.get(searchWord.toLowerCase());

        try (PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html>");
            out.println("<html lang=\"vi\"><head><meta charset=\"UTF-8\"><title>Kết quả tra từ</title></head><body>");
            if (meaning != null) {
                out.println("<p>" + escapeHtml(searchWord) + ": " + escapeHtml(meaning) + "</p>");
            } else {
                out.println("<p>Không tìm thấy từ: " + escapeHtml(searchWord) + "</p>");
            }
            out.println("<p><a href=\"index.jsp\">Quay lại</a></p>");
            out.println("</body></html>");
        }
    }

    private static String escapeHtml(String value) {
        return value.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&#39;");
    }
}
