<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Từ điển Anh - Việt</title>
</head>
<body>
    <h1>Từ điển Anh - Việt</h1>
    <form action="${pageContext.request.contextPath}/translate" method="post">
        <label for="word">Nhập từ tiếng Anh:</label>
        <input type="text" id="word" name="word" required>
        <button type="submit">Tìm kiếm</button>
    </form>
</body>
</html>
