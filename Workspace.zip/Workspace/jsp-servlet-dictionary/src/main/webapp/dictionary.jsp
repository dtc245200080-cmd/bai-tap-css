<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="java.util.Locale, java.util.Map" %>
<%!
    private String escapeHtml(String value) {
        return value.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&#39;");
    }
%>
<%
    request.setCharacterEncoding("UTF-8");

    Map<String, String> dictionary = Map.of(
            "hello", "Xin chào",
            "book", "Quyển sách",
            "computer", "Máy tính"
    );

    String searchWord = request.getParameter("search");
    searchWord = searchWord == null ? "" : searchWord.trim();

    String meaning = dictionary.get(searchWord.toLowerCase(Locale.ROOT));
    String result = meaning == null
            ? "Không tìm thấy từ: " + escapeHtml(searchWord)
            : escapeHtml(searchWord) + " - " + escapeHtml(meaning);
%>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Kết quả tra từ</title>
</head>
<body>
    <h1>Kết quả tra từ</h1>
    <p><%= result %></p>
    <p><a href="index.jsp">Quay lại</a></p>
</body>
</html>
