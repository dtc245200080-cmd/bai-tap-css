<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>iNotes Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-4">
    <h2 class="mb-4">iNotes Dashboard</h2>

    <!-- Chuyển đổi Strategy (Lưu trữ DB / File) -->
    <div class="mb-3 card p-3">
        <label class="fw-bold mb-2">Chuyển đổi Tầng lưu trữ (Strategy Pattern):</label>
        <div>
            <a href="notes?action=switchStorage&mode=db" class="btn btn-primary btn-sm me-2">Lưu vào Database (MySQL)</a>
            <a href="notes?action=switchStorage&mode=file" class="btn btn-secondary btn-sm">Lưu vào File (TXT)</a>
        </div>
    </div>

    <!-- Bước 4: Form Thêm mới Ghi chú -->
    <div class="card mb-4">
        <div class="card-header bg-primary text-white font-weight-bold">Thêm Mới Ghi Chú</div>
        <div class="card-body">
            <form action="notes" method="post">
                <div class="mb-3">
                    <label class="form-label">Tiêu đề:</label>
                    <input type="text" name="title" class="form-control" placeholder="Nhập tiêu đề ghi chú..." required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Phân loại:</label>
                    <select name="typeId" class="form-select">
                        <option value="1">Cá nhân</option>
                        <option value="2">Công việc</option>
                        <option value="3">Học tập</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Nội dung:</label>
                    <textarea name="content" class="form-control" rows="3" placeholder="Nhập nội dung ghi chú..."></textarea>
                </div>
                <button type="submit" class="btn btn-success">Lưu Ghi Chú</button>
                <button type="reset" class="btn btn-outline-secondary">Hủy bỏ</button>
            </form>
        </div>
    </div>

    <!-- Bước 5: Tìm kiếm & Danh sách Ghi chú -->
    <form action="notes" method="get" class="d-flex mb-3">
        <input type="text" name="search" class="form-control me-2" placeholder="Tìm kiếm theo tiêu đề hoặc nội dung...">
        <button type="submit" class="btn btn-outline-primary">Tìm kiếm</button>
    </form>

    <table class="table table-bordered table-striped bg-white">
        <thead class="table-dark">
            <tr>
                <th>#</th>
                <th>Tiêu đề</th>
                <th>Phân loại</th>
                <th>Thao tác</th>
            </tr>
        </thead>
        <tbody>
            <c:forEach var="note" items="${notes}">
                <tr>
                    <td>${note.id}</td>
                    <td>${note.title}</td>
                    <td>
                        <c:choose>
                            <c:when test="${note.typeId == 1}">Cá nhân</c:when>
                            <c:when test="${note.typeId == 2}">Công việc</c:when>
                            <c:when test="${note.typeId == 3}">Học tập</c:when>
                            <c:otherwise>Khác</c:otherwise>
                        </c:choose>
                    </td>
                    <td>
                        <a href="notes?action=delete&id=${note.id}" class="btn btn-danger btn-sm" onclick="return confirm('Bạn có chắc chắn muốn xóa?')">Xóa</a>
                    </td>
                </tr>
            </c:forEach>
        </tbody>
    </table>
</div>
</body>
</html>