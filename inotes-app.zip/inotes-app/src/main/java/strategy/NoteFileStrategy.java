package strategy;

import model.Note;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class NoteFileStrategy implements NoteStrategy {
    private final String filePath = "notes_data.txt";

    @Override
    public List<Note> findAll() {
        List<Note> notes = new ArrayList<>();
        File file = new File(filePath);
        if (!file.exists()) return notes;

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split("\\|");
                if (parts.length == 4) {
                    notes.add(new Note(
                        Integer.parseInt(parts[0]),
                        parts[1],
                        parts[2],
                        Integer.parseInt(parts[3])
                    ));
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return notes;
    }

    @Override
    public void save(Note note) {
        List<Note> notes = findAll();
        if (note.getId() <= 0) {
            int newId = notes.stream().mapToInt(Note::getId).max().orElse(0) + 1;
            note.setId(newId);
            notes.add(note);
        } else {
            for (int i = 0; i < notes.size(); i++) {
                if (notes.get(i).getId() == note.getId()) {
                    notes.set(i, note);
                    break;
                }
            }
        }
        writeAll(notes);
    }

    @Override
    public void delete(int id) {
        List<Note> notes = findAll();
        notes.removeIf(n -> n.getId() == id);
        writeAll(notes);
    }

    @Override
    public List<Note> search(String keyword) {
        List<Note> notes = findAll();
        List<Note> result = new ArrayList<>();
        for (Note n : notes) {
            if (n.getTitle().toLowerCase().contains(keyword.toLowerCase()) || 
                n.getContent().toLowerCase().contains(keyword.toLowerCase())) {
                result.add(n);
            }
        }
        return result;
    }

    private void writeAll(List<Note> notes) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(filePath))) {
            for (Note n : notes) {
                bw.write(n.getId() + "|" + n.getTitle() + "|" + n.getContent() + "|" + n.getTypeId());
                bw.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}