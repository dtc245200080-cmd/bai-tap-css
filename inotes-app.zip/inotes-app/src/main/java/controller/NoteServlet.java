package controller;

import strategy.NoteDBStrategy;
import strategy.NoteFileStrategy;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import java.io.IOException;

public class NoteServlet extends HttpServlet {
    private NoteManagement noteManagement = new NoteManagement();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        String action = req.getParameter("action");
        if (action == null) action = "";

        switch (action) {
            case "switchStorage":
                String mode = req.getParameter("mode");
                if ("file".equals(mode)) {
                    noteManagement.setStrategy(new NoteFileStrategy());
                } else {
                    noteManagement.setStrategy(new NoteDBStrategy());
                }
                resp.sendRedirect("notes");
                break;
            case "delete":
                int id = Integer.parseInt(req.getParameter("id"));
                noteManagement.deleteNote(id);
                resp.sendRedirect("notes");
                break;
            default:
                String keyword = req.getParameter("search");
                if (keyword != null && !keyword.trim().isEmpty()) {
                    req.setAttribute("notes", noteManagement.searchNotes(keyword));
                } else {
                    req.setAttribute("notes", noteManagement.getAllNotes());
                }
                req.getRequestDispatcher("index.jsp").forward(req, resp);
                break;
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        String title = req.getParameter("title");
        String content = req.getParameter("content");
        int typeId = Integer.parseInt(req.getParameter("typeId"));

        noteManagement.addNote(title, content, typeId);
        resp.sendRedirect("notes");
    }
}