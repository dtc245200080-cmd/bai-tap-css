package controller;

import model.Note;
import strategy.NoteFileStrategy;
import strategy.NoteStrategy;
import java.util.List;

public class NoteManagement {
    private NoteStrategy strategy;

    public NoteManagement() {
        this.strategy = new NoteFileStrategy();
    }

    // Cho phép đổi chiến lược lưu trữ linh hoạt lúc Runtime
    public void setStrategy(NoteStrategy strategy) {
        this.strategy = strategy;
    }

    public void addNote(String title, String content, int typeId) {
        Note note = new Note(title, content, typeId);
        strategy.save(note);
    }

    public void deleteNote(int id) {
        strategy.delete(id);
    }

    public List<Note> getAllNotes() {
        return strategy.findAll();
    }

    public List<Note> searchNotes(String keyword) {
        return strategy.search(keyword);
    }
}